// app.js
const express = require("express");
const mongoose = require("mongoose");
const customerRoute = require("./router/customerRoute");

const app = express();

mongoose.connect("mongodb://localhost:27017/custshop", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(express.json());
app.use("/api/", customerRoute);

const PORT = process.env.PORT || 3003;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
