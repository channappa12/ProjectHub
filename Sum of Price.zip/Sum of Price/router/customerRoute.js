const express = require("express");
const router = express.Router();
const customerControllers = require("../controller/customerController");
const productControllers = require("../controller/productController");
const purchaseControllers = require("../controller/purchaseController");

// Create customer
router.post("/customers", customerControllers.createCustomer);

// Create product
router.post("/products", productControllers.createProduct);

router.get(
  "/total-price/:customerId",
  purchaseControllers.getCustomerPurchasedProductsTotalPrice
);

module.exports = router;
